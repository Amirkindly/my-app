plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.verse.vpn"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.verse.vpn"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "0.2"
        resourceConfigurations += listOf("en", "fa")
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    buildTypes {
        debug {   // same shrinking as release, so the original assembleDebug workflow also gives a small APK
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("debug")   // installable without a keystore
        }
    }
    buildFeatures { compose = true }
    packaging { jniLibs { useLegacyPackaging = true } }   // native OpenVPN binary must exist as a real file to be executed
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    if (file("libs/libv2ray.aar").exists()) implementation(files("libs/libv2ray.aar"))   // Xray core, downloaded by the workflow
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.wireguard.android:tunnel:1.0.20230706")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
