package com.verse.vpn

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun attachBaseContext(newBase: Context) = super.attachBaseContext(Lang.wrap(newBase))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = VerseColors) { Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() } } }
    }
}

val VerseColors = darkColorScheme(
    primary = Color(0xFF2DD4BF), onPrimary = Color(0xFF00201C),
    secondary = Color(0xFFFFB454), onSecondary = Color(0xFF2B1800),
    background = Color(0xFF0A1118), surface = Color(0xFF0A1118), onSurface = Color(0xFFE6EEF2),
    surfaceVariant = Color(0xFF16222C), onSurfaceVariant = Color(0xFF9FB2BF),
    secondaryContainer = Color(0xFF12423D), onSecondaryContainer = Color(0xFFBFF5EC),
    error = Color(0xFFFF6B6B), outline = Color(0xFF3A4C59),
    surfaceContainerLowest = Color(0xFF070C11), surfaceContainerLow = Color(0xFF0E1620),
    surfaceContainer = Color(0xFF111B25), surfaceContainerHigh = Color(0xFF16222C), surfaceContainerHighest = Color(0xFF16222C),
)

@Composable
fun Header() {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF2DD4BF), Color(0xFF0E7C86)))), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Lock, null, tint = Color(0xFF00201C), modifier = Modifier.size(26.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(stringResource(R.string.app_name), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(stringResource(R.string.tagline), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf(R.string.tab_home, R.string.tab_configs, R.string.tab_apps, R.string.tab_tools, R.string.tab_settings)
    val icons = listOf(Icons.Filled.Home, Icons.Filled.Lock, Icons.Filled.Menu, Icons.Filled.Build, Icons.Filled.Settings)
    val status by VerseVpnService.status.collectAsState()
    LaunchedEffect(status) {
        status?.let { AppLog.add(if (it.contains("rror", true) || it.contains("خطا")) 'E' else 'I', it) }
    }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { Header() },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icons[i], null) }, label = { Text(stringResource(t)) },
                        colors = NavigationBarItemDefaults.colors(indicatorColor = MaterialTheme.colorScheme.secondaryContainer,
                            selectedIconColor = MaterialTheme.colorScheme.primary, selectedTextColor = MaterialTheme.colorScheme.primary))
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> ConnectScreen(store, 0) { tab = it }
                1 -> ConnectScreen(store, 1) { tab = it }
                2 -> AppsScreen(store)
                3 -> ToolsScreen()
                else -> SettingsScreen()
            }
        }
    }
}

@Composable
fun ConnectScreen(store: Store, section: Int, go: (Int) -> Unit) {
    val ctx = LocalContext.current
    var hop1 by remember { mutableStateOf(store.loadHop(1)) }
    var hop2 by remember { mutableStateOf(store.loadHop(2)) }
    var h2prefs by remember { mutableStateOf(store.loadHop2Prefs()) }
    var proxy by remember { mutableStateOf(store.loadProxy()) }
    var vless by remember { mutableStateOf(store.loadVless()) }
    var h1mode by remember { mutableStateOf(store.loadHop1Mode()) }
    var vless1 by remember { mutableStateOf(store.loadVless1()) }
    var hint by remember { mutableIntStateOf(0) }   // string resource id, 0 = none
    val status by VerseVpnService.status.collectAsState()
    val connected by VerseVpnService.active.collectAsState()

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        ctx.startForegroundService(Intent(ctx, VerseVpnService::class.java).setAction(VerseVpnService.ACTION_START))
    }
    fun toggle() {
        if (connected) { ctx.startService(Intent(ctx, VerseVpnService::class.java).setAction(VerseVpnService.ACTION_STOP)); return }
        if (h1mode == Hop1Mode.OPENVPN) {
            val h = hop1 ?: return
            if (h.needsAuth && (h.username.isBlank() || h.password.isBlank())) { hint = R.string.hint_hop1_auth; return }
        } else {
            if (VlessLink.parse(vless1) == null) { hint = R.string.hint_hop1_vless; return }
            if (h2prefs.enabled && h2prefs.mode != Hop2Mode.VPN) { hint = R.string.err_vless1_combo; return }
        }
        if (h2prefs.enabled) {
            if (h2prefs.mode == Hop2Mode.VPN && hop2 == null) { hint = R.string.hint_hop2_vpn; return }
            if (h2prefs.mode == Hop2Mode.PROXY && !proxy.valid) { hint = R.string.hint_hop2_proxy; return }
            if (h2prefs.mode == Hop2Mode.VLESS && VlessLink.parse(vless) == null) { hint = R.string.hint_hop2_vless; return }
        }
        hint = 0
        val prep = VpnService.prepare(ctx)
        if (prep != null) permLauncher.launch(prep)
        else ctx.startForegroundService(Intent(ctx, VerseVpnService::class.java).setAction(VerseVpnService.ACTION_START))
    }

    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        if (section == 0) {
            item { ConnectHero(connected, status, h1mode == Hop1Mode.VLESS || hop1 != null, hint, ::toggle) }
            item { HopFlow(connected, if (h1mode == Hop1Mode.VLESS) VlessLink.parse(vless1)?.host.orEmpty() else hop1?.host, if (!h2prefs.enabled) null else when (h2prefs.mode) { Hop2Mode.VPN -> hop2?.host.orEmpty(); Hop2Mode.PROXY -> proxy.host; Hop2Mode.VLESS -> VlessLink.parse(vless)?.host.orEmpty() }) }
            item { LiveStats(connected) }
            item { QuickActions(go) }
        } else {
            item { Hop1Header(h1mode, !connected) { h1mode = it; store.saveHop1Mode(it); hint = 0 } }
            item {
                if (h1mode == Hop1Mode.OPENVPN) HopCard(stringResource(R.string.hop1_title), hop1, !connected, { hop1 = it; store.saveHop(1, it) })
                else VlessCard(vless1, !connected, R.string.hop1_vless_card) { vless1 = it; store.saveVless1(it) }
            }
            item { Hop2Header(h2prefs, !connected) { h2prefs = it; store.saveHop2Prefs(it); hint = 0 } }
            if (h2prefs.enabled) {
                item {
                    when (h2prefs.mode) {
                        Hop2Mode.VPN -> HopCard(stringResource(R.string.hop2_vpn_card), hop2, !connected, { hop2 = it; store.saveHop(2, it) })
                        Hop2Mode.PROXY -> ProxyCard(proxy, !connected) { proxy = it; store.saveProxy(it) }
                        Hop2Mode.VLESS -> VlessCard(vless, !connected) { vless = it; store.saveVless(it) }
                    }
                }
            }
        }
    }
}

/** Switch that turns hop 2 on (it is off by default) + choice between VPN config and manual proxy. */
@Composable
fun Hop2Header(prefs: Hop2Prefs, editable: Boolean, onChange: (Hop2Prefs) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text(stringResource(R.string.hop2_title), style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Switch(prefs.enabled, { onChange(prefs.copy(enabled = it)) }, enabled = editable)
            }
            if (prefs.enabled) {
                listOf(Hop2Mode.VPN to R.string.hop2_mode_vpn, Hop2Mode.PROXY to R.string.hop2_mode_proxy, Hop2Mode.VLESS to R.string.hop2_mode_vless)
                    .forEach { (m, label) ->
                        Row(Modifier.fillMaxWidth().clickable(enabled = editable) { onChange(prefs.copy(mode = m)) },
                            verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(prefs.mode == m, { onChange(prefs.copy(mode = m)) }, enabled = editable)
                            Text(stringResource(label))
                        }
                    }
            } else Text(stringResource(R.string.hop2_off), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun ProxyCard(cfg: ProxyConfig, editable: Boolean, onChange: (ProxyConfig) -> Unit) {
    val ctx = LocalContext.current
    var portText by remember { mutableStateOf(cfg.port.toString()) }
    var testResult by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.hop2_proxy_card), style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(cfg.host, { onChange(cfg.copy(host = it.trim())) }, label = { Text(stringResource(R.string.proxy_address)) },
                singleLine = true, enabled = editable, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(portText, { v ->
                val d = v.filter { c -> c.isDigit() }.take(5)
                portText = d; onChange(cfg.copy(port = d.toIntOrNull() ?: 0))
            }, label = { Text(stringResource(R.string.port)) }, singleLine = true, enabled = editable,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(cfg.username, { onChange(cfg.copy(username = it)) }, label = { Text(stringResource(R.string.username_opt)) },
                singleLine = true, enabled = editable, modifier = Modifier.fillMaxWidth())
            PasswordField(cfg.password, { onChange(cfg.copy(password = it)) }, stringResource(R.string.password_opt), editable)
            OutlinedButton(onClick = {
                testing = true; testResult = ctx.getString(R.string.testing)
                scope.launch { testResult = HopTest.runProxy(ctx, cfg); testing = false }
            }, enabled = editable && !testing) { Text(stringResource(R.string.test)) }
            if (testResult.isNotEmpty()) Text(testResult, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun PasswordField(value: String, onChange: (String) -> Unit, label: String, enabled: Boolean) {
    var show by remember { mutableStateOf(false) }
    OutlinedTextField(value, onChange, label = { Text(label) }, singleLine = true, enabled = enabled,
        visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
        trailingIcon = { TextButton(onClick = { show = !show }) { Text(stringResource(if (show) R.string.hide_pw else R.string.show_pw)) } },
        modifier = Modifier.fillMaxWidth())
}

@Composable
fun HopCard(title: String, cfg: HopConfig?, editable: Boolean, onChange: (HopConfig?) -> Unit) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readText().orEmpty()
        val name = uri.lastPathSegment?.substringAfterLast('/')?.substringAfter('-') ?: "config"
        onChange(ConfigParser.parse(name, text))
    }
    var testResult by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (cfg == null) Text(stringResource(R.string.no_config)) else {
                Text("${cfg.name} · ${cfg.type} · ${cfg.host}:${cfg.port}")
                // username/password only when the config asks for it (auth-user-pass)
                if (cfg.needsAuth) {
                    OutlinedTextField(cfg.username, { onChange(cfg.copy(username = it)) }, label = { Text(stringResource(R.string.username)) },
                        singleLine = true, enabled = editable, modifier = Modifier.fillMaxWidth())
                    PasswordField(cfg.password, { onChange(cfg.copy(password = it)) }, stringResource(R.string.password), editable)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = editable) { Text(stringResource(R.string.import_config)) }
                if (cfg != null) OutlinedButton(onClick = { onChange(null) }, enabled = editable) { Text(stringResource(R.string.remove)) }
                if (cfg != null) OutlinedButton(onClick = {
                    testing = true; testResult = ctx.getString(R.string.testing)
                    scope.launch { testResult = HopTest.run(ctx, cfg); testing = false }
                }, enabled = editable && !testing) { Text(stringResource(R.string.test)) }
            }
            if (testResult.isNotEmpty()) Text(testResult, style = MaterialTheme.typography.bodySmall)
        }
    }
}

data class AppItem(val label: String, val pkg: String)

@Composable
fun AppsScreen(store: Store) {
    val ctx = LocalContext.current
    var routing by remember { mutableStateOf(store.loadRouting()) }
    var apps by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { loadApps(ctx) } }
    fun update(r: Routing) { routing = r; store.saveRouting(r) }

    Column(Modifier.padding(16.dp)) {
        Text(stringResource(R.string.apps_question), style = MaterialTheme.typography.titleMedium)
        listOf(
            SplitMode.ALL to R.string.apps_all,
            SplitMode.EXCLUDE to R.string.apps_exclude,
            SplitMode.ONLY to R.string.apps_only,
        ).forEach { (m, label) ->
            Row(Modifier.fillMaxWidth().clickable { update(routing.copy(mode = m)) }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(routing.mode == m, { update(routing.copy(mode = m)) }); Text(stringResource(label))
            }
        }
        if (routing.mode != SplitMode.ALL) {
            OutlinedTextField(query, { query = it }, label = { Text(stringResource(R.string.search)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            val shown = remember(apps, query) { apps.filter { it.label.contains(query, true) || it.pkg.contains(query, true) } }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.apps_selected, routing.packages.size), style = MaterialTheme.typography.bodySmall)
                Row {
                    TextButton({ update(routing.copy(packages = routing.packages + shown.map { it.pkg })) }) { Text(stringResource(R.string.apps_select_all)) }
                    TextButton({ update(routing.copy(packages = emptySet())) }) { Text(stringResource(R.string.apps_clear)) }
                }
            }
            LazyColumn {
                items(shown) { a ->
                    val on = a.pkg in routing.packages
                    val toggle = { update(routing.copy(packages = if (on) routing.packages - a.pkg else routing.packages + a.pkg)) }
                    Row(Modifier.fillMaxWidth().clickable { toggle() }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(on, { toggle() })
                        Column { Text(a.label); Text(a.pkg, style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
        }
    }
}

/** Language choice (applies immediately) + About / credits. */
@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    var lang by remember { mutableStateOf(Lang.saved(ctx)) }
    val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull().orEmpty() }
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { NetworkCard() }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(stringResource(R.string.settings_language), style = MaterialTheme.typography.titleMedium)
                    listOf("system" to R.string.lang_system, "en" to R.string.lang_en, "fa" to R.string.lang_fa).forEach { (code, label) ->
                        val pick = {
                            if (code != lang) {
                                lang = code
                                Lang.save(ctx, code)
                                (ctx as? Activity)?.recreate()
                            }
                        }
                        Row(Modifier.fillMaxWidth().clickable { pick() }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(lang == code, { pick() }); Text(stringResource(label))
                        }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.about_title), style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(R.string.about_text))
                    if (version.isNotEmpty()) Text(stringResource(R.string.version, version), style = MaterialTheme.typography.bodySmall)
                    OutlinedButton(onClick = {
                        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/Amir_verse"))) }
                    }) { Text(stringResource(R.string.open_telegram)) }
                }
            }
        }
    }
}

private fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    return pm.getInstalledApplications(0)
        .filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != ctx.packageName }
        .map { AppItem(pm.getApplicationLabel(it).toString(), it.packageName) }
        .sortedBy { it.label.lowercase() }
}


@Composable
fun ConnectHero(connected: Boolean, status: String?, enabled: Boolean, hint: Int, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val pulse = rememberInfiniteTransition(label = "pulse")
    val k by pulse.animateFloat(1f, 1.12f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "k")
    val scale = if (connected) k else 1f
    val ring = if (connected) cs.primary else cs.outline
    Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(210.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(190.dp).graphicsLayer { scaleX = scale; scaleY = scale }
                .border(2.dp, ring.copy(alpha = 0.35f), CircleShape))
            Box(Modifier.size(150.dp).clip(CircleShape)
                .background(Brush.radialGradient(if (connected) listOf(Color(0xFF2DD4BF), Color(0xFF0E7C86)) else listOf(Color(0xFF26343F), Color(0xFF16222C))))
                .clickable(enabled = enabled, onClick = onClick), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    PowerIcon(if (connected) Color(0xFF00201C) else cs.onSurfaceVariant, 44.dp)
                    Spacer(Modifier.height(4.dp))
                    Text(stringResource(if (connected) R.string.disconnect else R.string.connect), fontWeight = FontWeight.SemiBold,
                        color = if (connected) Color(0xFF00201C) else cs.onSurface)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(status ?: stringResource(R.string.status_disconnected), textAlign = TextAlign.Center, maxLines = 4, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 12.dp),
            color = if (connected) cs.primary else cs.onSurfaceVariant, style = MaterialTheme.typography.titleMedium)
        if (hint != 0) Text(stringResource(hint), color = cs.error, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
    }
}

/** Two stage cards (hop 1 -> hop 2) showing what the chain is made of and whether it is live. */
@Composable
fun HopFlow(connected: Boolean, hop1: String?, hop2: String?) {
    val cs = MaterialTheme.colorScheme
    @Composable fun stage(n: Int, title: Int, value: String, on: Boolean, m: Modifier) {
        Column(m.clip(RoundedCornerShape(18.dp)).background(cs.surfaceVariant)
            .border(1.dp, if (on) cs.primary.copy(alpha = 0.6f) else cs.outline.copy(alpha = 0.4f), RoundedCornerShape(18.dp)).padding(14.dp)) {
            Text("$n", color = if (on) cs.primary else cs.onSurfaceVariant, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(stringResource(title), fontSize = 11.sp, color = cs.onSurfaceVariant, maxLines = 1)
            Text(value, fontWeight = FontWeight.Medium, maxLines = 1, fontSize = 13.sp)
        }
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        stage(1, R.string.stage_1, hop1 ?: "—", connected, Modifier.weight(1f))
        Icon(Icons.Filled.ArrowForward, null, tint = cs.secondary, modifier = Modifier.padding(horizontal = 6.dp))
        stage(2, R.string.stage_2, hop2 ?: stringResource(R.string.hop_off), connected && hop2 != null, Modifier.weight(1f))
    }
}

@Composable
fun VlessCard(link: String, editable: Boolean, title: Int = R.string.hop2_vless_card, onChange: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var testResult by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    val parsed = remember(link) { VlessLink.parse(link) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(title), style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(link, { onChange(it.trim()) }, label = { Text(stringResource(R.string.vless_link)) },
                enabled = editable, minLines = 3, modifier = Modifier.fillMaxWidth())
            if (link.isNotEmpty()) {
                if (parsed != null) Text(stringResource(R.string.vless_ok, parsed.host, parsed.port, parsed.network),
                    color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                else Text(stringResource(R.string.vless_bad), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            if (parsed != null) OutlinedButton(onClick = {
                testing = true; testResult = ctx.getString(R.string.testing)
                scope.launch { testResult = HopTest.run(ctx, HopConfig(parsed.name, HopType.OTHER, "", false, parsed.host, parsed.port, tcp = true)); testing = false }
            }, enabled = editable && !testing) { Text(stringResource(R.string.test)) }
            if (testResult.isNotEmpty()) Text(testResult, style = MaterialTheme.typography.bodySmall)
        }
    }
}
