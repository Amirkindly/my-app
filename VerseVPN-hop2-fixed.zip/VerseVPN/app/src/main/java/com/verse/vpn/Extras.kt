package com.verse.vpn

import android.content.Context
import android.net.TrafficStats
import android.os.Process
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class LogLine(val t: Long, val level: Char, val msg: String)

/** In-memory event log (last 400 lines). Never receives passwords or keys. */
object AppLog {
    val lines = MutableStateFlow<List<LogLine>>(emptyList())
    fun add(level: Char, msg: String) { lines.value = (lines.value + LogLine(System.currentTimeMillis(), level, msg)).takeLast(400) }
    fun clear() { lines.value = emptyList() }
    fun fmt(l: LogLine): String = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(l.t)) + "  " + l.level + "  " + l.msg
}

/** DNS / MTU preferences (same SharedPreferences file as Store). */
object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("verse", Context.MODE_PRIVATE)
    fun customDns(c: Context) = p(c).contains("dns1")
    fun dns1(c: Context) = p(c).getString("dns1", "1.1.1.1").orEmpty()
    fun dns2(c: Context) = p(c).getString("dns2", "8.8.8.8").orEmpty()
    fun mtu(c: Context) = p(c).getInt("mtu", 1280)
    fun save(c: Context, d1: String, d2: String, mtu: Int) =
        p(c).edit().putString("dns1", d1).putString("dns2", d2).putInt("mtu", mtu).apply()
    fun reset(c: Context) = p(c).edit().remove("dns1").remove("dns2").remove("mtu").apply()
    fun blockIpv6(c: Context) = p(c).getBoolean("block_v6", false)
    fun setBlockIpv6(c: Context, on: Boolean) = p(c).edit().putBoolean("block_v6", on).apply()
    /** Wipes saved configs, credentials, DNS/MTU and app rules; keeps the language choice. */
    fun resetAll(c: Context) { val l = Lang.saved(c); p(c).edit().clear().putString("lang", l).apply() }
    fun validIp(s: String): Boolean {
        val parts = s.split('.')
        return parts.size == 4 && parts.all { it.length in 1..3 && it.all(Char::isDigit) && it.toInt() in 0..255 }
    }
}

object Fmt {
    fun bytes(b: Long): String = when {
        b < 1024 -> "$b B"
        b < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
        b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
        else -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    }
    fun speed(bps: Long): String = bytes(bps) + "/s"
    fun clock(sec: Long): String = String.format(Locale.US, "%02d:%02d:%02d", sec / 3600, sec / 60 % 60, sec % 60)
}

/** Traffic of this app's UID: the tunnel sockets live here, so it approximates VPN traffic. */
object Meter {
    fun rx(): Long = TrafficStats.getUidRxBytes(Process.myUid()).coerceAtLeast(0)
    fun tx(): Long = TrafficStats.getUidTxBytes(Process.myUid()).coerceAtLeast(0)
}

object NetTools {
    suspend fun ip(): String = withContext(Dispatchers.IO) {
        val c = URL("https://ipinfo.io/json").openConnection() as HttpURLConnection
        c.connectTimeout = 6000; c.readTimeout = 6000
        try {
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            listOf(j.optString("ip"), listOf(j.optString("city"), j.optString("country")).filter { it.isNotBlank() }.joinToString(", "), j.optString("org"))
                .filter { it.isNotBlank() }.joinToString("\n")
        } finally { c.disconnect() }
    }

    /** TCP connect time in ms, or -1 on failure. */
    suspend fun ping(host: String, port: Int): Long = withContext(Dispatchers.IO) {
        val t0 = System.nanoTime()
        runCatching { Socket().use { it.connect(InetSocketAddress(host, port), 4000) } }
            .map { (System.nanoTime() - t0) / 1_000_000 }.getOrDefault(-1L)
    }

    /** Returns Pair(bytes, seconds) of a 5 MB download. */
    suspend fun speed(): Pair<Long, Double> = withContext(Dispatchers.IO) {
        val c = URL("https://speed.cloudflare.com/__down?bytes=5000000").openConnection() as HttpURLConnection
        c.connectTimeout = 6000; c.readTimeout = 10000
        try {
            val t0 = System.nanoTime()
            var total = 0L
            val buf = ByteArray(32 * 1024)
            c.inputStream.use { s -> while (true) { val n = s.read(buf); if (n < 0) break; total += n } }
            Pair(total, (System.nanoTime() - t0) / 1e9)
        } finally { c.disconnect() }
    }
}
