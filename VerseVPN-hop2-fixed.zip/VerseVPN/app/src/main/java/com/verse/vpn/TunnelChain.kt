package com.verse.vpn

import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Hop 1 engine (outer): carries raw IP packets to/from the first server (OpenVPN).
 * Its own transport socket MUST be protect()ed so it bypasses our TUN.
 */
interface PacketTunnel {
    var onPacket: ((ByteArray) -> Unit)?      // packet coming back from the server -> goes into TUN
    fun start(protect: (Int) -> Boolean)
    fun send(packet: ByteArray)               // packet from TUN -> goes to the server
    fun stop()
}

/**
 * Hop 2 engine (inner): takes plaintext app packets, encrypts them, and emits its own
 * UDP/TCP packets through ordinary (NOT protected) sockets, so they enter the TUN and
 * get picked up by TunnelChain and handed to hop 1.
 */
interface InnerTunnel {
    var onPlain: ((ByteArray) -> Unit)?       // decrypted reply packet -> goes into TUN
    fun start()
    fun send(packet: ByteArray)               // plaintext app packet -> encrypt
    fun stop()
}

/**
 * Double-hop forwarder around the single system TUN.
 *   app packet            -> hop2 (encrypt)  -> hop2 outer packet (dst = server 2) -> hop1 -> server 1 -> server 2 -> internet
 *   packet with dst==srv2 -> hop1
 * With only hop 1 configured, everything goes straight to hop 1.
 */
class TunnelChain(
    private val tun: ParcelFileDescriptor,
    private val hop1: PacketTunnel,
    private val hop2: InnerTunnel?,
    private val hop2Ip: ByteArray?,
) {
    @Volatile private var running = true

    fun run() {
        val input = FileInputStream(tun.fileDescriptor)
        val output = FileOutputStream(tun.fileDescriptor)
        val sink: (ByteArray) -> Unit = { synchronized(output) { runCatching { output.write(it) } } }
        hop1.onPacket = sink
        hop2?.onPlain = sink
        val buf = ByteArray(32767)
        while (running) {
            val n = input.read(buf)
            if (n <= 0) continue
            if ((buf[0].toInt() shr 4) != 4) continue   // only IPv4 is tunnelled; IPv6 (when blocked) is dropped here
            val pkt = buf.copyOf(n)
            when {
                hop2 == null -> hop1.send(pkt)
                destIsHop2(pkt) -> hop1.send(pkt)
                else -> hop2.send(pkt)
            }
        }
    }

    private fun destIsHop2(p: ByteArray): Boolean {
        if (hop2Ip == null || p.size < 20 || (p[0].toInt() shr 4) != 4) return false
        for (i in 0 until 4) if (p[16 + i] != hop2Ip[i]) return false
        return true
    }

    fun stop() { running = false; runCatching { tun.close() }; hop2?.stop(); hop1.stop() }
}
