# Verse VPN (double-hop) - status

Tabs: Home, Configs, Apps, Tools (IP, latency, speed, logs), Settings (DNS, MTU, language).
Hop 1 = OpenVPN (EXPERIMENTAL): libovpnexec.so from ics-openvpn, run as a child process and driven over its management
interface (OpenVpnEngine.kt). Built by ci/native.sh in GitHub Actions.
Hop 2 (optional) = WireGuard config, SOCKS5 proxy, or a vless:// link (Xray via libv2ray.aar + hev-socks5-tunnel).
Nothing here could be run before shipping: expect to iterate using the error text shown in the app and ci/native.log.

Note: ics-openvpn is GPLv2, so builds that include its binary fall under GPLv2.
Build: GitHub Actions workflow (.github/workflows/build.yml) unzips VerseVPN-hop2.zip and builds the APK.
