#!/usr/bin/env bash
# Builds/downloads the native parts. Each part is independent: if one fails the app still builds,
# and the app shows which engine is missing. Full log: ci/native.log (uploaded as an artifact).
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WORK="$(mktemp -d)"
LOG="$ROOT/ci/native.log"
: > "$LOG"
NDK="${ANDROID_NDK_LATEST_HOME:-$ANDROID_NDK_HOME}"
JNI="$ROOT/app/src/main/jniLibs"
step() { echo "=== $1" | tee -a "$LOG"; }

step "1/3 Xray (libv2ray.aar)"
(
  set -e
  mkdir -p "$ROOT/app/libs"
  curl -fL -o "$ROOT/app/libs/libv2ray.aar" https://github.com/2dust/AndroidLibXrayLite/releases/latest/download/libv2ray.aar
  ls -la "$ROOT/app/libs"
) >> "$LOG" 2>&1 && echo "OK xray" || echo "FAILED xray"

step "2/3 hev-socks5-tunnel (tun2socks)"
(
  set -e
  mkdir -p "$WORK/hev/jni" && cd "$WORK/hev"
  git clone --recursive --depth 1 --shallow-submodules https://github.com/heiher/hev-socks5-tunnel jni/hev-socks5-tunnel
  echo 'include $(call all-subdir-makefile)' > jni/Android.mk
  "$NDK/ndk-build" NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=jni/Android.mk APP_ABI="arm64-v8a armeabi-v7a" APP_PLATFORM=android-26 NDK_LIBS_OUT=./libs NDK_OUT=./obj -j4
  for abi in arm64-v8a armeabi-v7a; do
    mkdir -p "$JNI/$abi"; cp "libs/$abi/libhev-socks5-tunnel.so" "$JNI/$abi/"
  done
  ls -la "$JNI"/*
) >> "$LOG" 2>&1 && echo "OK hev" || echo "FAILED hev"

step "3/3 OpenVPN (from ics-openvpn)"
(
  set -e
  sudo apt-get update -qq && sudo apt-get install -y -qq swig ninja-build
  cd "$WORK"
  git clone --recurse-submodules --depth 1 --shallow-submodules https://github.com/schwabe/ics-openvpn.git ics
  cd ics
  yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null || true
  ./gradlew --no-daemon assembleUiDebug || ./gradlew --no-daemon assembleDebug
  mkdir -p "$WORK/icslibs"
  for apk in $(find . -name "*.apk"); do unzip -oq "$apk" 'lib/*' -d "$WORK/icslibs" || true; done
  ls -R "$WORK/icslibs" | head -60
  for abi in arm64-v8a armeabi-v7a; do
    if [ -d "$WORK/icslibs/lib/$abi" ]; then mkdir -p "$JNI/$abi"; cp "$WORK/icslibs/lib/$abi/"*.so "$JNI/$abi/"; fi
  done
  test -f "$JNI/arm64-v8a/libovpnexec.so"
) >> "$LOG" 2>&1 && echo "OK openvpn" || echo "FAILED openvpn"

echo "--- native build summary ---"
ls -la "$JNI"/* "$ROOT/app/libs" 2>/dev/null
exit 0
