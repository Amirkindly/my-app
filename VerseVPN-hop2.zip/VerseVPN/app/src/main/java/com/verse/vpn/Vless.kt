package com.verse.vpn

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.lang.reflect.Proxy
import java.net.InetSocketAddress
import java.net.Socket

/** A parsed vless:// share link. */
data class VlessLink(val uuid: String, val host: String, val port: Int, val params: Map<String, String>, val name: String) {
    val network: String get() = params["type"].orEmpty().ifEmpty { "tcp" }

    companion object {
        fun parse(s: String): VlessLink? = runCatching {
            val t = s.trim()
            if (!t.startsWith("vless://")) return null
            val u = Uri.parse(t)
            val uuid = u.userInfo?.takeIf { it.isNotBlank() } ?: return null
            val host = u.host?.takeIf { it.isNotBlank() } ?: return null
            val port = u.port.takeIf { it in 1..65535 } ?: return null
            val params = u.queryParameterNames.associateWith { u.getQueryParameter(it).orEmpty() }
            VlessLink(uuid, host, port, params, u.fragment.orEmpty())
        }.getOrNull()
    }

    /** Xray config: local SOCKS5 inbound (with UDP) -> VLESS outbound. */
    fun toXrayJson(socksPort: Int): String {
        fun p(k: String) = params[k].orEmpty()
        val net = network
        val sec = p("security").ifEmpty { "none" }
        val user = JSONObject().put("id", uuid).put("encryption", p("encryption").ifEmpty { "none" })
        if (p("flow").isNotEmpty()) user.put("flow", p("flow"))
        val ss = JSONObject().put("network", net).put("security", sec)
        when (net) {
            "ws" -> ss.put("wsSettings", JSONObject().put("path", p("path").ifEmpty { "/" })
                .put("headers", JSONObject().put("Host", p("host").ifEmpty { host })))
            "grpc" -> ss.put("grpcSettings", JSONObject().put("serviceName", p("serviceName")).put("multiMode", p("mode") == "multi"))
        }
        when (sec) {
            "tls" -> ss.put("tlsSettings", JSONObject().put("serverName", p("sni").ifEmpty { host })
                .put("fingerprint", p("fp").ifEmpty { "chrome" })
                .apply { if (p("alpn").isNotEmpty()) put("alpn", JSONArray(p("alpn").split(","))) })
            "reality" -> ss.put("realitySettings", JSONObject().put("serverName", p("sni")).put("fingerprint", p("fp").ifEmpty { "chrome" })
                .put("publicKey", p("pbk")).put("shortId", p("sid")).put("spiderX", p("spx")))
        }
        val out = JSONObject().put("tag", "proxy").put("protocol", "vless")
            .put("settings", JSONObject().put("vnext", JSONArray().put(JSONObject().put("address", host).put("port", port)
                .put("users", JSONArray().put(user)))))
            .put("streamSettings", ss)
        val inbound = JSONObject().put("tag", "socks").put("listen", "127.0.0.1").put("port", socksPort).put("protocol", "socks")
            .put("settings", JSONObject().put("auth", "noauth").put("udp", true).put("ip", "127.0.0.1"))
        return JSONObject().put("log", JSONObject().put("loglevel", "warning"))
            .put("inbounds", JSONArray().put(inbound))
            .put("outbounds", JSONArray().put(out).put(JSONObject().put("tag", "direct").put("protocol", "freedom")))
            .toString()
    }
}

/** Loads Xray through the libv2ray.aar by reflection (its API changed between releases), so the app builds even without it. */
object XrayCore {
    private var controller: Any? = null

    private fun stub(cls: Class<*>): Any = Proxy.newProxyInstance(cls.classLoader, arrayOf(cls)) { _, m, _ ->
        when (m.returnType) {
            java.lang.Boolean.TYPE -> false
            java.lang.Long.TYPE -> 0L
            java.lang.Integer.TYPE -> 0
            String::class.java -> ""
            else -> null
        }
    }

    fun start(ctx: Context, json: String) {
        val lib = try { Class.forName("libv2ray.Libv2ray") }
        catch (e: ClassNotFoundException) { error("Xray (libv2ray.aar) is not bundled: its download failed in GitHub Actions") }
        val path = ctx.filesDir.absolutePath
        val newCtl = lib.methods.firstOrNull { it.name == "newCoreController" }
        if (newCtl != null) {
            lib.methods.firstOrNull { it.name == "initCoreEnv" }?.invoke(null, path, "")
            val c = newCtl.invoke(null, stub(newCtl.parameterTypes[0]))!!
            controller = c
            val sl = c.javaClass.methods.first { it.name == "startLoop" }
            if (sl.parameterCount == 1) sl.invoke(c, json)
            else sl.invoke(c, json, if (sl.parameterTypes[1] == java.lang.Long.TYPE) 0L else 0)
        } else {
            lib.methods.firstOrNull { it.name == "initV2Env" }?.let { m -> if (m.parameterCount == 2) m.invoke(null, path, "") else m.invoke(null, path) }
            val np = lib.methods.first { it.name == "newV2RayPoint" }
            val sup = stub(np.parameterTypes[0])
            val pt = (if (np.parameterCount == 2) np.invoke(null, sup, false) else np.invoke(null, sup))!!
            controller = pt
            pt.javaClass.methods.first { it.name == "setConfigureFileContent" }.invoke(pt, json)
            pt.javaClass.methods.first { it.name == "runLoop" }.invoke(pt, false)
        }
    }

    fun stop() {
        runCatching { controller?.let { c -> c.javaClass.methods.first { it.name == "stopLoop" }.invoke(c) } }
        controller = null
    }
}

/** Hop 2 = VLESS: Xray exposes a local SOCKS5, and hev-socks5-tunnel (inside ProxyEngine) turns our TUN packets into SOCKS5. */
class VlessEngine(private val link: VlessLink, private val ctx: Context) : InnerTunnel {
    private val port = 10808
    private val inner = ProxyEngine(ProxyConfig("127.0.0.1", port), "127.0.0.1", ctx.filesDir)
    override var onPlain: ((ByteArray) -> Unit)?
        get() = inner.onPlain
        set(v) { inner.onPlain = v }

    override fun start() {
        XrayCore.start(ctx, link.toXrayJson(port))
        var up = false
        for (i in 0 until 20) {
            up = runCatching { Socket().use { it.connect(InetSocketAddress("127.0.0.1", port), 300) }; true }.getOrDefault(false)
            if (up) break
            Thread.sleep(250)
        }
        if (!up) { XrayCore.stop(); error("Xray did not start (invalid VLESS config?)") }
        inner.start()
    }

    override fun send(packet: ByteArray) = inner.send(packet)
    override fun stop() { inner.stop(); XrayCore.stop() }
}
