package com.verse.vpn

import android.os.ParcelFileDescriptor
import android.system.Os
import android.system.OsConstants
import com.wireguard.android.backend.GoBackend
import com.wireguard.config.Config
import java.io.File
import java.io.FileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.concurrent.thread

/**
 * Hop 2 = WireGuard. wireguard-go's "TUN" is one end of a unix socketpair; we shuttle packets on the other end.
 * Its UDP sockets are deliberately NOT protected: they enter our TUN and TunnelChain forwards them through hop 1.
 */
class WireGuardEngine(private val cfg: HopConfig) : InnerTunnel {
    override var onPlain: ((ByteArray) -> Unit)? = null
    private var handle = -1
    private var ours: ParcelFileDescriptor? = null
    @Volatile private var running = false

    override fun start() {
        val a = FileDescriptor(); val b = FileDescriptor()
        Os.socketpair(OsConstants.AF_UNIX, OsConstants.SOCK_DGRAM, 0, a, b)
        val wgSide = ParcelFileDescriptor.dup(a); ours = ParcelFileDescriptor.dup(b)
        Os.close(a); Os.close(b)

        val config = Config.parse(cfg.raw.byteInputStream())
        // wgTurnOn is a private static JNI method of GoBackend (libwg-go.so is loaded by that class)
        val m = GoBackend::class.java.getDeclaredMethod("wgTurnOn", String::class.java, Int::class.javaPrimitiveType, String::class.java)
        m.isAccessible = true
        handle = m.invoke(null, "verse2", wgSide.detachFd(), config.toWgUserspaceString()) as Int
        check(handle >= 0) { "wireguard-go failed to start ($handle)" }

        running = true
        val input = FileInputStream(ours!!.fileDescriptor)
        thread(isDaemon = true) {
            val buf = ByteArray(32767)
            while (running) { val n = runCatching { input.read(buf) }.getOrDefault(-1); if (n <= 0) break; onPlain?.invoke(buf.copyOf(n)) }
        }
    }

    private val out by lazy { FileOutputStream(ours!!.fileDescriptor) }
    override fun send(packet: ByteArray) { runCatching { out.write(packet) } }

    override fun stop() {
        running = false
        if (handle >= 0) runCatching {
            val m = GoBackend::class.java.getDeclaredMethod("wgTurnOff", Int::class.javaPrimitiveType)
            m.isAccessible = true; m.invoke(null, handle)
        }
        runCatching { ours?.close() }
    }
}

/**
 * Hop 2 in PROXY mode = a manually entered SOCKS5 proxy.
 * A proxy speaks TCP streams, not IP packets, so the packets coming out of the TUN must go through a userspace
 * TCP/IP stack ("tun2socks"). We use hev-socks5-tunnel the same way WireGuardEngine uses wireguard-go: it gets one end
 * of a unix socketpair as its "TUN" and we shuttle raw IP packets on the other end.
 *
 * Its sockets to the proxy are deliberately NOT protected: they enter our TUN and TunnelChain forwards them through hop 1.
 * That is why [proxyIp] must be a numeric IPv4 resolved BEFORE the tunnel exists (a DNS lookup now would loop back into this hop).
 *
 * NOT linked yet: add the hev-socks5-tunnel Android library (class hev.htproxy.TProxyService, JNI TProxyStartService /
 * TProxyStopService). Until then start() fails with a clear error. UNTESTED against the real library.
 * Note: DNS inside the tunnel goes over UDP, so the proxy must support SOCKS5 UDP ASSOCIATE.
 */
class ProxyEngine(
    private val cfg: ProxyConfig,
    private val proxyIp: String,
    private val workDir: File,
) : InnerTunnel {
    override var onPlain: ((ByteArray) -> Unit)? = null
    private var ours: ParcelFileDescriptor? = null
    private var svc: Class<*>? = null
    @Volatile private var running = false

    private fun q(s: String) = "'" + s.replace("'", "''") + "'"

    override fun start() {
        val cls = try { Class.forName("hev.htproxy.TProxyService") }
        catch (e: ClassNotFoundException) { error("Proxy mode needs the tun2socks library (hev-socks5-tunnel), not linked yet") }
        svc = cls

        val a = FileDescriptor(); val b = FileDescriptor()
        Os.socketpair(OsConstants.AF_UNIX, OsConstants.SOCK_DGRAM, 0, a, b)
        val tunSide = ParcelFileDescriptor.dup(a); ours = ParcelFileDescriptor.dup(b)
        Os.close(a); Os.close(b)

        val yaml = buildString {
            appendLine("tunnel:"); appendLine("  mtu: 1280"); appendLine("  ipv4: 198.18.0.1")
            appendLine("socks5:"); appendLine("  port: ${cfg.port}"); appendLine("  address: ${q(proxyIp)}"); appendLine("  udp: 'udp'")
            if (cfg.username.isNotEmpty()) { appendLine("  username: ${q(cfg.username)}"); appendLine("  password: ${q(cfg.password)}") }
            appendLine("misc:"); appendLine("  log-level: warn")
        }
        val f = File(workDir, "verse-proxy.yml").apply { writeText(yaml) }
        cls.getDeclaredMethod("TProxyStartService", String::class.java, Int::class.javaPrimitiveType)
            .invoke(null, f.absolutePath, tunSide.detachFd())

        running = true
        val input = FileInputStream(ours!!.fileDescriptor)
        thread(isDaemon = true) {
            val buf = ByteArray(32767)
            while (running) { val n = runCatching { input.read(buf) }.getOrDefault(-1); if (n <= 0) break; onPlain?.invoke(buf.copyOf(n)) }
        }
    }

    private val out by lazy { FileOutputStream(ours!!.fileDescriptor) }
    override fun send(packet: ByteArray) { runCatching { out.write(packet) } }

    override fun stop() {
        running = false
        runCatching { svc?.getDeclaredMethod("TProxyStopService")?.invoke(null) }
        runCatching { ours?.close() }
        runCatching { File(workDir, "verse-proxy.yml").delete() }   // may hold the proxy password
    }
}
