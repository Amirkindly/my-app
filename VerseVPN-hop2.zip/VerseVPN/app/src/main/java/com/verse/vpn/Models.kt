package com.verse.vpn

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

enum class HopType { OPENVPN, WIREGUARD, OTHER }
enum class SplitMode { ALL, EXCLUDE, ONLY }   // all apps / all except selected / only selected

data class HopConfig(
    val name: String,
    val type: HopType,
    val raw: String,
    val needsAuth: Boolean,
    val host: String,
    val port: Int,
    val username: String = "",
    val password: String = "",
    val tcp: Boolean = false,
)

data class Routing(val mode: SplitMode = SplitMode.ALL, val packages: Set<String> = emptySet())

/** Hop 2 is optional and off by default. When on, it is either a VPN config (WireGuard) or a manual SOCKS5 proxy. */
enum class Hop2Mode { VPN, PROXY }

data class Hop2Prefs(val enabled: Boolean = false, val mode: Hop2Mode = Hop2Mode.VPN)

/** Manually entered SOCKS5 proxy (optional username/password). */
data class ProxyConfig(
    val host: String = "",
    val port: Int = 1080,
    val username: String = "",
    val password: String = "",
) {
    val valid: Boolean get() = host.isNotBlank() && port in 1..65535
}

/** Detects type / host / port / "auth-user-pass" from a config file's text. */
object ConfigParser {
    fun parse(name: String, text: String): HopConfig {
        val t = text.trim()
        return when {
            Regex("^\\s*\\[Interface]", RegexOption.MULTILINE).containsMatchIn(t) -> {
                val ep = Regex("^\\s*Endpoint\\s*=\\s*(.+)$", RegexOption.MULTILINE).find(t)?.groupValues?.get(1)?.trim().orEmpty()
                val host = ep.substringBeforeLast(":", ep).trim('[', ']')
                val port = ep.substringAfterLast(":", "51820").toIntOrNull() ?: 51820
                HopConfig(name, HopType.WIREGUARD, t, false, host, port)
            }
            Regex("^\\s*(client|remote)\\b", RegexOption.MULTILINE).containsMatchIn(t) -> {
                val rem = Regex("^\\s*remote\\s+(\\S+)(?:\\s+(\\d+))?", RegexOption.MULTILINE).find(t)
                val gPort = Regex("^\\s*port\\s+(\\d+)", RegexOption.MULTILINE).find(t)?.groupValues?.get(1)?.toIntOrNull()
                val needs = Regex("^\\s*auth-user-pass\\s*$", RegexOption.MULTILINE).containsMatchIn(t)
                val proto = Regex("^\\s*proto\\s+(\\S+)", RegexOption.MULTILINE).find(t)?.groupValues?.get(1)
                    ?: Regex("^\\s*remote\\s+\\S+\\s+\\d+\\s+(\\S+)", RegexOption.MULTILINE).find(t)?.groupValues?.get(1) ?: "udp"
                HopConfig(name, HopType.OPENVPN, t, needs, rem?.groupValues?.get(1).orEmpty(),
                    rem?.groupValues?.get(2)?.toIntOrNull() ?: gPort ?: 1194, tcp = proto.startsWith("tcp"))
            }
            else -> HopConfig(name, HopType.OTHER, t, false, "", 0)
        }
    }
}

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("verse", Context.MODE_PRIVATE)

    fun saveHop(index: Int, c: HopConfig?) {
        val e = p.edit()
        if (c == null) e.remove("hop$index") else e.putString("hop$index", JSONObject().apply {
            put("name", c.name); put("type", c.type.name); put("raw", c.raw); put("auth", c.needsAuth)
            put("host", c.host); put("port", c.port); put("user", c.username); put("pass", c.password); put("tcp", c.tcp)
        }.toString())
        e.apply()
    }

    fun loadHop(index: Int): HopConfig? = p.getString("hop$index", null)?.let {
        val j = JSONObject(it)
        HopConfig(j.getString("name"), HopType.valueOf(j.getString("type")), j.getString("raw"), j.getBoolean("auth"),
            j.getString("host"), j.getInt("port"), j.optString("user"), j.optString("pass"), j.optBoolean("tcp"))
    }

    fun saveProxy(c: ProxyConfig) = p.edit().putString("proxy", JSONObject().apply {
        put("host", c.host); put("port", c.port); put("user", c.username); put("pass", c.password)
    }.toString()).apply()

    fun loadProxy(): ProxyConfig = p.getString("proxy", null)?.let {
        val j = JSONObject(it)
        ProxyConfig(j.optString("host"), j.optInt("port", 1080), j.optString("user"), j.optString("pass"))
    } ?: ProxyConfig()

    fun saveHop2Prefs(h: Hop2Prefs) = p.edit().putBoolean("h2_on", h.enabled).putString("h2_mode", h.mode.name).apply()

    fun loadHop2Prefs(): Hop2Prefs = Hop2Prefs(
        p.getBoolean("h2_on", false),
        runCatching { Hop2Mode.valueOf(p.getString("h2_mode", "VPN").orEmpty()) }.getOrDefault(Hop2Mode.VPN),
    )

    fun saveRouting(r: Routing) = p.edit().putString("routing", JSONObject().apply {
        put("mode", r.mode.name); put("pkgs", JSONArray(r.packages.toList()))
    }.toString()).apply()

    fun loadRouting(): Routing = p.getString("routing", null)?.let {
        val j = JSONObject(it)
        val a = j.getJSONArray("pkgs")
        Routing(SplitMode.valueOf(j.getString("mode")), (0 until a.length()).map { i -> a.getString(i) }.toSet())
    } ?: Routing()
}
