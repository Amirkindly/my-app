package com.verse.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.flow.MutableStateFlow
import java.net.Inet4Address
import java.net.InetAddress
import kotlin.concurrent.thread

class VerseVpnService : VpnService() {
    companion object {
        const val ACTION_START = "verse.START"
        const val ACTION_STOP = "verse.STOP"
        /** Text to show; null = "Disconnected" (the UI localizes it). */
        val status = MutableStateFlow<String?>(null)
        /** true while connecting or connected. */
        val active = MutableStateFlow(false)
        /** Epoch ms when the tunnel came up; 0 = not connected. */
        val since = MutableStateFlow(0L)
    }

    private var chain: TunnelChain? = null
    private var tun: ParcelFileDescriptor? = null
    @Volatile private var stopped = false

    override fun attachBaseContext(newBase: Context) = super.attachBaseContext(Lang.wrap(newBase))

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopAll(); return START_NOT_STICKY }
        stopped = false
        active.value = true
        startForeground(1, notif())
        thread {
            runCatching { start() }.onFailure {
                // a normal disconnect also ends start() with an exception (the TUN gets closed): not an error
                if (!stopped) { status.value = getString(R.string.status_error, it.message.orEmpty()); stopAll(keepStatus = true) }
            }
        }
        return START_STICKY
    }

    private var hop1Ref: PacketTunnel? = null

    private fun start() {
        val store = Store(this)
        val mode1 = store.loadHop1Mode()
        val h1: HopConfig? = if (mode1 == Hop1Mode.OPENVPN) store.loadHop(1) ?: error(getString(R.string.err_hop1_missing)) else null
        val v1: VlessLink? = if (mode1 == Hop1Mode.VLESS) VlessLink.parse(store.loadVless1()) ?: error(getString(R.string.err_hop1_vless)) else null
        val routing = store.loadRouting()
        status.value = getString(R.string.status_connecting)

        // Hop 2 is optional: VPN config (WireGuard), manual SOCKS5 proxy, or a VLESS link (Xray)
        val prefs = store.loadHop2Prefs()
        val h2: HopConfig? = if (prefs.enabled && prefs.mode == Hop2Mode.VPN)
            store.loadHop(2) ?: error(getString(R.string.err_hop2_vpn)) else null
        val proxy: ProxyConfig? = if (prefs.enabled && prefs.mode == Hop2Mode.PROXY)
            store.loadProxy().also { if (!it.valid) error(getString(R.string.err_hop2_proxy)) } else null
        val vless: VlessLink? = if (prefs.enabled && prefs.mode == Hop2Mode.VLESS)
            VlessLink.parse(store.loadVless()) ?: error(getString(R.string.err_hop2_vless)) else null

        if (v1 != null && prefs.enabled && prefs.mode != Hop2Mode.VPN) error(getString(R.string.err_vless1_combo))

        // resolve hop-2 server BEFORE the tunnel exists (a lookup afterwards would loop back into hop 2)
        val hop2Host = h2?.host ?: proxy?.host ?: vless?.host
        val hop2Addr: Inet4Address? = hop2Host?.let { h ->
            InetAddress.getAllByName(h).firstOrNull { a -> a is Inet4Address } as? Inet4Address
                ?: error(getString(R.string.err_no_ipv4, h))
        }
        val hop2Ip = hop2Addr?.address

        val hop1: PacketTunnel = if (v1 != null) VlessHop1(v1, this) else OpenVpnEngine(this, h1!!)
        hop1Ref = hop1
        val hop2: InnerTunnel? = when {
            h2 != null -> if (h2.type == HopType.WIREGUARD) WireGuardEngine(h2) else error(getString(R.string.err_hop2_type, h2.type.name))
            proxy != null -> ProxyEngine(proxy, hop2Addr!!.hostAddress.orEmpty(), filesDir)
            vless != null -> VlessEngine(vless, this)
            else -> null
        }

        // 1) bring hop 1 up FIRST (its socket is protected, so no TUN is needed yet); it blocks until the OpenVPN tunnel is up
        hop1.start { protect(it) }
        // 2) our system TUN gets the tunnel IP that the OpenVPN server assigned us, so the server accepts our packets
        val ovpn = hop1 as? OpenVpnEngine
        val ovDns = ovpn?.dns?.toList().orEmpty()
        val ip = ovpn?.tunnelIp ?: "10.77.0.2"
        val dns = if (hop2 == null && ovDns.isNotEmpty() && !Prefs.customDns(this)) ovDns
            else listOf(Prefs.dns1(this), Prefs.dns2(this)).filter { Prefs.validIp(it) }.ifEmpty { listOf("1.1.1.1", "8.8.8.8") }

        // VLESS hop 1 without hop 2: Xray lives in this app, so keep this app out of the TUN (no loop)
        val ownOut = v1 != null && hop2 == null
        val b = Builder().setSession("Verse VPN").setMtu(Prefs.mtu(this))
            .addAddress(ip, 32).addRoute("0.0.0.0", 0)
        dns.forEach { b.addDnsServer(it) }
        when (routing.mode) {
            SplitMode.ALL -> if (ownOut) runCatching { b.addDisallowedApplication(packageName) }
            SplitMode.EXCLUDE -> {
                routing.packages.filter { it != packageName }.forEach { runCatching { b.addDisallowedApplication(it) } }
                if (ownOut) runCatching { b.addDisallowedApplication(packageName) }
            }
            SplitMode.ONLY -> {
                if (!ownOut) runCatching { b.addAllowedApplication(packageName) }   // hop-2 sockets live in this app
                routing.packages.forEach { runCatching { b.addAllowedApplication(it) } }
            }
        }
        tun = b.establish() ?: error(getString(R.string.err_vpn_permission))

        hop2?.start()
        status.value = getString(when {
            h2 != null -> R.string.status_connected_vpn
            proxy != null || vless != null -> R.string.status_connected_proxy
            else -> R.string.status_connected1
        })
        since.value = System.currentTimeMillis()
        chain = TunnelChain(tun!!, hop1, hop2, hop2Ip).also { it.run() }
    }

    private fun stopAll(keepStatus: Boolean = false) {
        stopped = true
        chain?.stop(); chain = null
        runCatching { hop1Ref?.stop() }; hop1Ref = null
        runCatching { tun?.close() }; tun = null
        active.value = false
        since.value = 0L
        if (!keepStatus) status.value = null
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    override fun onRevoke() = stopAll()
    override fun onDestroy() { stopAll(keepStatus = true); super.onDestroy() }

    private fun notif(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("verse", "Verse VPN", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "verse").setContentTitle("Verse VPN").setContentText(getString(R.string.notif_active))
            .setSmallIcon(android.R.drawable.ic_lock_lock).build()
    }
}
