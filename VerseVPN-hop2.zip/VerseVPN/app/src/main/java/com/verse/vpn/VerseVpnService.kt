package com.verse.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.flow.MutableStateFlow
import java.net.Inet4Address
import java.net.InetAddress
import kotlin.concurrent.thread

class VerseVpnService : VpnService() {
    companion object {
        const val ACTION_START = "verse.START"
        const val ACTION_STOP = "verse.STOP"
        /** Text to show; null = "Disconnected" (the UI localizes it). */
        val status = MutableStateFlow<String?>(null)
        /** true while connecting or connected. */
        val active = MutableStateFlow(false)
    }

    private var chain: TunnelChain? = null
    private var tun: ParcelFileDescriptor? = null
    @Volatile private var stopped = false

    override fun attachBaseContext(newBase: Context) = super.attachBaseContext(Lang.wrap(newBase))

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopAll(); return START_NOT_STICKY }
        stopped = false
        active.value = true
        startForeground(1, notif())
        thread {
            runCatching { start() }.onFailure {
                // a normal disconnect also ends start() with an exception (the TUN gets closed): not an error
                if (!stopped) { status.value = getString(R.string.status_error, it.message.orEmpty()); stopAll(keepStatus = true) }
            }
        }
        return START_STICKY
    }

    private fun start() {
        val store = Store(this)
        val h1 = store.loadHop(1) ?: error(getString(R.string.err_hop1_missing))
        val routing = store.loadRouting()
        status.value = getString(R.string.status_connecting)

        // Hop 2 is optional: it is only used when switched on, and then as either a VPN config or a manual proxy
        val prefs = store.loadHop2Prefs()
        val h2: HopConfig? = if (prefs.enabled && prefs.mode == Hop2Mode.VPN)
            store.loadHop(2) ?: error(getString(R.string.err_hop2_vpn)) else null
        val proxy: ProxyConfig? = if (prefs.enabled && prefs.mode == Hop2Mode.PROXY)
            store.loadProxy().also { if (!it.valid) error(getString(R.string.err_hop2_proxy)) } else null

        // resolve hop-2 server BEFORE the tunnel exists (a lookup afterwards would loop back into hop 2)
        val hop2Host = h2?.host ?: proxy?.host
        val hop2Addr: Inet4Address? = hop2Host?.let { h ->
            InetAddress.getAllByName(h).firstOrNull { a -> a is Inet4Address } as? Inet4Address
                ?: error(getString(R.string.err_no_ipv4, h))
        }
        val hop2Ip = hop2Addr?.address

        val b = Builder().setSession("Verse VPN").setMtu(1280)
            .addAddress("10.77.0.2", 32).addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1").addDnsServer("8.8.8.8")
        when (routing.mode) {
            SplitMode.ALL -> {}
            SplitMode.EXCLUDE -> routing.packages.filter { it != packageName }.forEach { runCatching { b.addDisallowedApplication(it) } }
            SplitMode.ONLY -> {
                runCatching { b.addAllowedApplication(packageName) }   // hop-2 sockets live in this app
                routing.packages.forEach { runCatching { b.addAllowedApplication(it) } }
            }
        }
        tun = b.establish() ?: error(getString(R.string.err_vpn_permission))

        val hop1 = OpenVpnEngine(h1)
        val hop2: InnerTunnel? = when {
            h2 != null -> if (h2.type == HopType.WIREGUARD) WireGuardEngine(h2) else error(getString(R.string.err_hop2_type, h2.type.name))
            proxy != null -> ProxyEngine(proxy, hop2Addr!!.hostAddress.orEmpty(), filesDir)
            else -> null
        }
        hop1.start { protect(it) }
        hop2?.start()
        status.value = getString(when {
            h2 != null -> R.string.status_connected_vpn
            proxy != null -> R.string.status_connected_proxy
            else -> R.string.status_connected1
        })
        chain = TunnelChain(tun!!, hop1, hop2, hop2Ip).also { it.run() }
    }

    private fun stopAll(keepStatus: Boolean = false) {
        stopped = true
        chain?.stop(); chain = null
        runCatching { tun?.close() }; tun = null
        active.value = false
        if (!keepStatus) status.value = null
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    override fun onRevoke() = stopAll()
    override fun onDestroy() { stopAll(keepStatus = true); super.onDestroy() }

    private fun notif(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("verse", "Verse VPN", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "verse").setContentTitle("Verse VPN").setContentText(getString(R.string.notif_active))
            .setSmallIcon(android.R.drawable.ic_lock_lock).build()
    }
}
