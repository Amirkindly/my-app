package com.verse.vpn

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun attachBaseContext(newBase: Context) = super.attachBaseContext(Lang.wrap(newBase))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf(R.string.tab_connect, R.string.tab_apps, R.string.tab_settings)
    Scaffold(
        topBar = { TopAppBar(title = { Text("Verse VPN") }) },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = {}, label = { Text(stringResource(t)) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> ConnectScreen(store)
                1 -> AppsScreen(store)
                else -> SettingsScreen()
            }
        }
    }
}

@Composable
fun ConnectScreen(store: Store) {
    val ctx = LocalContext.current
    var hop1 by remember { mutableStateOf(store.loadHop(1)) }
    var hop2 by remember { mutableStateOf(store.loadHop(2)) }
    var h2prefs by remember { mutableStateOf(store.loadHop2Prefs()) }
    var proxy by remember { mutableStateOf(store.loadProxy()) }
    var hint by remember { mutableIntStateOf(0) }   // string resource id, 0 = none
    val status by VerseVpnService.status.collectAsState()
    val connected by VerseVpnService.active.collectAsState()

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        ctx.startForegroundService(Intent(ctx, VerseVpnService::class.java).setAction(VerseVpnService.ACTION_START))
    }
    fun toggle() {
        if (connected) { ctx.startService(Intent(ctx, VerseVpnService::class.java).setAction(VerseVpnService.ACTION_STOP)); return }
        val h = hop1 ?: return
        if (h.needsAuth && (h.username.isBlank() || h.password.isBlank())) { hint = R.string.hint_hop1_auth; return }
        if (h2prefs.enabled) {
            if (h2prefs.mode == Hop2Mode.VPN && hop2 == null) { hint = R.string.hint_hop2_vpn; return }
            if (h2prefs.mode == Hop2Mode.PROXY && !proxy.valid) { hint = R.string.hint_hop2_proxy; return }
        }
        hint = 0
        val prep = VpnService.prepare(ctx)
        if (prep != null) permLauncher.launch(prep)
        else ctx.startForegroundService(Intent(ctx, VerseVpnService::class.java).setAction(VerseVpnService.ACTION_START))
    }

    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(status ?: stringResource(R.string.status_disconnected), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Button(onClick = ::toggle, enabled = hop1 != null) {
                    Text(stringResource(if (connected) R.string.disconnect else R.string.connect))
                }
                if (hint != 0) Text(stringResource(hint), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        }
        item { HopCard(stringResource(R.string.hop1_title), hop1, !connected, { hop1 = it; store.saveHop(1, it) }) }
        item { Hop2Header(h2prefs, !connected) { h2prefs = it; store.saveHop2Prefs(it); hint = 0 } }
        if (h2prefs.enabled) {
            item {
                if (h2prefs.mode == Hop2Mode.VPN)
                    HopCard(stringResource(R.string.hop2_vpn_card), hop2, !connected, { hop2 = it; store.saveHop(2, it) })
                else
                    ProxyCard(proxy, !connected) { proxy = it; store.saveProxy(it) }
            }
        }
    }
}

/** Switch that turns hop 2 on (it is off by default) + choice between VPN config and manual proxy. */
@Composable
fun Hop2Header(prefs: Hop2Prefs, editable: Boolean, onChange: (Hop2Prefs) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text(stringResource(R.string.hop2_title), style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Switch(prefs.enabled, { onChange(prefs.copy(enabled = it)) }, enabled = editable)
            }
            if (prefs.enabled) {
                listOf(Hop2Mode.VPN to R.string.hop2_mode_vpn, Hop2Mode.PROXY to R.string.hop2_mode_proxy)
                    .forEach { (m, label) ->
                        Row(Modifier.fillMaxWidth().clickable(enabled = editable) { onChange(prefs.copy(mode = m)) },
                            verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(prefs.mode == m, { onChange(prefs.copy(mode = m)) }, enabled = editable)
                            Text(stringResource(label))
                        }
                    }
            } else Text(stringResource(R.string.hop2_off), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun ProxyCard(cfg: ProxyConfig, editable: Boolean, onChange: (ProxyConfig) -> Unit) {
    val ctx = LocalContext.current
    var portText by remember { mutableStateOf(cfg.port.toString()) }
    var testResult by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.hop2_proxy_card), style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(cfg.host, { onChange(cfg.copy(host = it.trim())) }, label = { Text(stringResource(R.string.proxy_address)) },
                singleLine = true, enabled = editable, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(portText, { v ->
                val d = v.filter { c -> c.isDigit() }.take(5)
                portText = d; onChange(cfg.copy(port = d.toIntOrNull() ?: 0))
            }, label = { Text(stringResource(R.string.port)) }, singleLine = true, enabled = editable,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(cfg.username, { onChange(cfg.copy(username = it)) }, label = { Text(stringResource(R.string.username_opt)) },
                singleLine = true, enabled = editable, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(cfg.password, { onChange(cfg.copy(password = it)) }, label = { Text(stringResource(R.string.password_opt)) },
                singleLine = true, enabled = editable, visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = {
                testing = true; testResult = ctx.getString(R.string.testing)
                scope.launch { testResult = HopTest.runProxy(ctx, cfg); testing = false }
            }, enabled = editable && !testing) { Text(stringResource(R.string.test)) }
            if (testResult.isNotEmpty()) Text(testResult, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun HopCard(title: String, cfg: HopConfig?, editable: Boolean, onChange: (HopConfig?) -> Unit) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readText().orEmpty()
        val name = uri.lastPathSegment?.substringAfterLast('/')?.substringAfter('-') ?: "config"
        onChange(ConfigParser.parse(name, text))
    }
    var testResult by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (cfg == null) Text(stringResource(R.string.no_config)) else {
                Text("${cfg.name} · ${cfg.type} · ${cfg.host}:${cfg.port}")
                // username/password only when the config asks for it (auth-user-pass)
                if (cfg.needsAuth) {
                    OutlinedTextField(cfg.username, { onChange(cfg.copy(username = it)) }, label = { Text(stringResource(R.string.username)) },
                        singleLine = true, enabled = editable, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(cfg.password, { onChange(cfg.copy(password = it)) }, label = { Text(stringResource(R.string.password)) },
                        singleLine = true, enabled = editable, visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth())
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { picker.launch(arrayOf("*/*")) }, enabled = editable) { Text(stringResource(R.string.import_config)) }
                if (cfg != null) OutlinedButton(onClick = { onChange(null) }, enabled = editable) { Text(stringResource(R.string.remove)) }
                if (cfg != null) OutlinedButton(onClick = {
                    testing = true; testResult = ctx.getString(R.string.testing)
                    scope.launch { testResult = HopTest.run(ctx, cfg); testing = false }
                }, enabled = editable && !testing) { Text(stringResource(R.string.test)) }
            }
            if (testResult.isNotEmpty()) Text(testResult, style = MaterialTheme.typography.bodySmall)
        }
    }
}

data class AppItem(val label: String, val pkg: String)

@Composable
fun AppsScreen(store: Store) {
    val ctx = LocalContext.current
    var routing by remember { mutableStateOf(store.loadRouting()) }
    var apps by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { loadApps(ctx) } }
    fun update(r: Routing) { routing = r; store.saveRouting(r) }

    Column(Modifier.padding(16.dp)) {
        Text(stringResource(R.string.apps_question), style = MaterialTheme.typography.titleMedium)
        listOf(
            SplitMode.ALL to R.string.apps_all,
            SplitMode.EXCLUDE to R.string.apps_exclude,
            SplitMode.ONLY to R.string.apps_only,
        ).forEach { (m, label) ->
            Row(Modifier.fillMaxWidth().clickable { update(routing.copy(mode = m)) }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(routing.mode == m, { update(routing.copy(mode = m)) }); Text(stringResource(label))
            }
        }
        if (routing.mode != SplitMode.ALL) {
            OutlinedTextField(query, { query = it }, label = { Text(stringResource(R.string.search)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            LazyColumn {
                items(apps.filter { it.label.contains(query, true) || it.pkg.contains(query, true) }) { a ->
                    val on = a.pkg in routing.packages
                    val toggle = { update(routing.copy(packages = if (on) routing.packages - a.pkg else routing.packages + a.pkg)) }
                    Row(Modifier.fillMaxWidth().clickable { toggle() }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(on, { toggle() })
                        Column { Text(a.label); Text(a.pkg, style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }
        }
    }
}

/** Language choice (applies immediately) + About / credits. */
@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    var lang by remember { mutableStateOf(Lang.saved(ctx)) }
    val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull().orEmpty() }
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(stringResource(R.string.settings_language), style = MaterialTheme.typography.titleMedium)
                    listOf("system" to R.string.lang_system, "en" to R.string.lang_en, "fa" to R.string.lang_fa).forEach { (code, label) ->
                        val pick = {
                            if (code != lang) {
                                lang = code
                                Lang.save(ctx, code)
                                (ctx as? Activity)?.recreate()
                            }
                        }
                        Row(Modifier.fillMaxWidth().clickable { pick() }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(lang == code, { pick() }); Text(stringResource(label))
                        }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.about_title), style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(R.string.about_text))
                    if (version.isNotEmpty()) Text(stringResource(R.string.version, version), style = MaterialTheme.typography.bodySmall)
                    OutlinedButton(onClick = {
                        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/Amir_verse"))) }
                    }) { Text(stringResource(R.string.open_telegram)) }
                }
            }
        }
    }
}

private fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    return pm.getInstalledApplications(0)
        .filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != ctx.packageName }
        .map { AppItem(pm.getApplicationLabel(it).toString(), it.packageName) }
        .sortedBy { it.label.lowercase() }
}
