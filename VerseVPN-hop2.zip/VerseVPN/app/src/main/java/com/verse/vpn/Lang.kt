package com.verse.vpn

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/** In-app language: "system" (follow the phone), "en" or "fa". Applied through attachBaseContext. */
object Lang {
    private const val KEY = "lang"

    fun saved(ctx: Context): String =
        ctx.getSharedPreferences("verse", Context.MODE_PRIVATE).getString(KEY, "system") ?: "system"

    fun save(ctx: Context, code: String) {
        ctx.getSharedPreferences("verse", Context.MODE_PRIVATE).edit().putString(KEY, code).apply()
    }

    fun wrap(base: Context): Context {
        val code = saved(base)
        if (code == "system") return base
        val loc = Locale(code)
        Locale.setDefault(loc)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(loc)
        cfg.setLayoutDirection(loc)
        return base.createConfigurationContext(cfg)
    }
}
