package com.verse.vpn

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.DataInputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/** Checks a hop's server from the CURRENT network (run with the VPN off). */
object HopTest {
    /** Connects to the SOCKS5 proxy and performs the greeting (+ username/password auth if given). */
    suspend fun runProxy(ctx: Context, c: ProxyConfig): String = withContext(Dispatchers.IO) {
        if (!c.valid) return@withContext ctx.getString(R.string.p_enter)
        val addr = try { InetAddress.getByName(c.host) } catch (e: Exception) { return@withContext ctx.getString(R.string.t_dns_failed, c.host) }
        val t0 = System.nanoTime()
        fun ms() = (System.nanoTime() - t0) / 1_000_000
        runCatching {
            Socket().use { s ->
                s.connect(InetSocketAddress(addr, c.port), 4000)
                s.soTimeout = 4000
                val out = s.getOutputStream()
                val inp = DataInputStream(s.getInputStream())
                val withAuth = c.username.isNotEmpty()
                out.write(if (withAuth) byteArrayOf(5, 2, 0, 2) else byteArrayOf(5, 1, 0)); out.flush()
                val r = ByteArray(2); inp.readFully(r)
                if (r[0].toInt() != 5) return@runCatching ctx.getString(R.string.p_not_socks)
                when (r[1].toInt() and 0xFF) {
                    0x00 -> ctx.getString(R.string.p_ok_noauth, ms())
                    0x02 -> {
                        if (!withAuth) return@runCatching ctx.getString(R.string.p_need_auth)
                        val u = c.username.toByteArray(); val p = c.password.toByteArray()
                        if (u.size > 255 || p.size > 255) return@runCatching ctx.getString(R.string.p_too_long)
                        out.write(byteArrayOf(1, u.size.toByte()) + u + byteArrayOf(p.size.toByte()) + p); out.flush()
                        val a = ByteArray(2); inp.readFully(a)
                        if (a[1].toInt() == 0) ctx.getString(R.string.p_ok_auth, ms()) else ctx.getString(R.string.p_bad_auth)
                    }
                    else -> ctx.getString(R.string.p_no_method)
                }
            }
        }.getOrElse { ctx.getString(R.string.p_unreachable, c.host, c.port, it.message.orEmpty()) } + ctx.getString(R.string.p_note)
    }

    suspend fun run(ctx: Context, c: HopConfig): String = withContext(Dispatchers.IO) {
        if (c.host.isBlank()) return@withContext ctx.getString(R.string.t_no_host)
        val t0 = System.nanoTime()
        val addr = try { InetAddress.getByName(c.host) } catch (e: Exception) { return@withContext ctx.getString(R.string.t_dns_failed, c.host) }
        val dnsMs = (System.nanoTime() - t0) / 1_000_000
        val head = ctx.getString(R.string.t_head, c.host, addr.hostAddress.orEmpty(), dnsMs) + "\n"

        // ICMP ping (works on many networks without root; may be blocked by the server/network)
        val icmp = runCatching {
            val s = System.nanoTime()
            if (addr.isReachable(3000)) ctx.getString(R.string.t_ping_ms, (System.nanoTime() - s) / 1_000_000)
            else ctx.getString(R.string.t_ping_none)
        }.getOrDefault(ctx.getString(R.string.t_ping_unavail))

        if (c.tcp) {
            val r = runCatching {
                val s = System.nanoTime()
                Socket().use { it.connect(InetSocketAddress(addr, c.port), 4000) }
                ctx.getString(R.string.t_tcp_open, c.port, (System.nanoTime() - s) / 1_000_000)
            }.getOrElse { ctx.getString(R.string.t_tcp_closed, c.port, it.message.orEmpty()) }
            "$head$r\n$icmp"
        } else {
            // UDP can't be verified without a protocol handshake, so we report DNS + ICMP only.
            "$head$icmp\n" + ctx.getString(R.string.t_udp_note, c.port)
        }
    }
}
