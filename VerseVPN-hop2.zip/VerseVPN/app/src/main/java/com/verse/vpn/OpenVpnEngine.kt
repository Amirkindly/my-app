package com.verse.vpn

import android.content.Context
import android.net.LocalServerSocket
import android.net.LocalSocket
import android.net.LocalSocketAddress
import android.os.ParcelFileDescriptor
import android.system.Os
import android.system.OsConstants
import java.io.File
import java.io.FileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Hop 1 = OpenVPN, run as a child process (libovpnexec.so from ics-openvpn, built by the GitHub workflow)
 * and controlled over its management interface, exactly like the ics-openvpn app does:
 *   - PROTECTFD  : openvpn sends us its transport socket, we protect() it so it bypasses our TUN
 *   - IFCONFIG   : tells us the tunnel IP (we give our system TUN that same address, so the server accepts our packets)
 *   - OPENTUN    : we answer with one end of a unix socketpair as the "tun" fd, and shuttle raw IP packets on the other end
 * EXPERIMENTAL: written without being able to run it. Errors are shown in the app with the last OpenVPN log lines.
 */
class OpenVpnEngine(private val ctx: Context, private val cfg: HopConfig) : PacketTunnel {
    override var onPacket: ((ByteArray) -> Unit)? = null
    @Volatile var tunnelIp: String? = null
    val dns = CopyOnWriteArrayList<String>()

    private var proc: Process? = null
    private var bound: LocalSocket? = null
    private var server: LocalServerSocket? = null
    @Volatile private var mgmt: LocalSocket? = null
    private var ours: ParcelFileDescriptor? = null
    @Volatile private var tunOut: FileOutputStream? = null
    @Volatile private var running = false
    @Volatile private var failure: String? = null
    private val ready = CountDownLatch(1)
    private val lock = Any()
    private val logTail = java.util.ArrayDeque<String>()
    private val confFile = File(ctx.cacheDir, "ovpn.conf")
    private val sockFile = File(ctx.cacheDir, "ovpn.sock")
    private var protectFn: (Int) -> Boolean = { true }

    @Volatile private var lastState = "-"
    private fun addLog(s: String) {
        if (s.contains("MANAGEMENT: CMD")) return   // would echo the username
        AppLog.add('I', "ovpn: " + s.take(300))
        synchronized(logTail) { logTail.addLast(s); while (logTail.size > 15) logTail.removeFirst() }
    }
    private fun tail(): String = synchronized(logTail) { logTail.joinToString("\n") }
    private fun fail(msg: String) { if (failure == null) failure = msg; ready.countDown() }
    private fun q(s: String) = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

    override fun start(protect: (Int) -> Boolean) {
        protectFn = protect
        val dir = ctx.applicationInfo.nativeLibraryDir
        val bin = File(dir, "libovpnexec.so")
        if (!bin.exists()) error("OpenVPN binary (libovpnexec.so) is not bundled: the OpenVPN build step failed in GitHub Actions")
        running = true
        sockFile.delete()
        val ls = LocalSocket()
        ls.bind(LocalSocketAddress(sockFile.absolutePath, LocalSocketAddress.Namespace.FILESYSTEM))
        bound = ls
        server = LocalServerSocket(ls.fileDescriptor)
        confFile.writeText(buildConfig())
        confFile.setReadable(false, false); confFile.setReadable(true, true)

        val pb = ProcessBuilder(bin.absolutePath, "--config", confFile.absolutePath)
        pb.environment()["LD_LIBRARY_PATH"] = dir + (System.getenv("LD_LIBRARY_PATH")?.let { ":$it" } ?: "")
        pb.redirectErrorStream(true)
        val p = pb.start(); proc = p
        thread(isDaemon = true) {
            runCatching { p.inputStream.bufferedReader().forEachLine { addLog(it) } }
            if (running && ready.count > 0) fail("OpenVPN exited early:\n" + tail())
        }
        thread(isDaemon = true) {
            runCatching { manage() }.onFailure { if (running && ready.count > 0) fail((it.message ?: "management error") + "\n" + tail()) }
        }
        if (!ready.await(60, TimeUnit.SECONDS)) fail("Timed out waiting for OpenVPN (stuck at: $lastState)\n" + tail())
        failure?.let { msg -> stop(); error(msg) }
    }

    private fun buildConfig(): String {
        val drop = Regex("^\\s*(management\\S*|daemon|log|log-append|syslog|up|down|route-up|route-pre-down|script-security|" +
            "ifconfig-noexec|route-noexec|dev|dev-node|dev-type|auth-user-pass.*|user|group|chroot|writepid|verb)(\\s.*)?$")
        val kept = cfg.raw.lines().filterNot { drop.matches(it) }.joinToString("\n")
        return kept + "\n" + buildString {
            appendLine("dev tun")
            if (cfg.needsAuth) appendLine("auth-user-pass")
            appendLine("management ${sockFile.absolutePath} unix")
            appendLine("management-client")
            appendLine("management-query-passwords")
            appendLine("management-hold")
            appendLine("ifconfig-nowarn")
            appendLine("verb 3")
        }
    }

    private fun send(cmd: String) = synchronized(lock) { mgmt?.outputStream?.let { it.write(cmd.toByteArray()); it.flush() } }

    private fun manage() {
        val s = server!!.accept(); mgmt = s
        val inp = s.inputStream
        send("version 3\n"); send("state on\n"); send("log on all\n")
        val buf = ByteArray(8192); val sb = StringBuilder()
        while (running) {
            val n = inp.read(buf); if (n < 0) break
            val fds = s.ancillaryFileDescriptors
            sb.append(String(buf, 0, n, Charsets.UTF_8))
            while (true) {
                val i = sb.indexOf("\n"); if (i < 0) break
                val line = sb.substring(0, i).trimEnd('\r'); sb.delete(0, i + 1)
                handle(line, fds)
            }
        }
    }

    private fun handle(line: String, fds: Array<FileDescriptor>?) {
        when {
            line.startsWith(">HOLD:") -> send("hold release\n")
            line.startsWith(">PASSWORD:") -> when {
                line.contains("Verification Failed") -> fail("OpenVPN authentication failed (wrong username/password?)")
                line.contains("'Auth'") -> { send("username \"Auth\" ${q(cfg.username)}\n"); send("password \"Auth\" ${q(cfg.password)}\n") }
                else -> fail("Unsupported OpenVPN credential request: $line")
            }
            line.startsWith(">NEED-OK:") -> need(line.removePrefix(">NEED-OK:"), fds)
            line.startsWith(">STATE:") -> { lastState = line.removePrefix(">STATE:").split(',').getOrNull(1).orEmpty(); addLog(line); if (line.contains(",EXITING,")) fail("OpenVPN is exiting:\n" + tail()) }
            line.startsWith(">FATAL:") -> fail(line)
            line.startsWith(">LOG:") -> {}   // same text already arrives on stdout
        }
    }

    private fun need(arg: String, fds: Array<FileDescriptor>?) {
        val m = Regex("Need '([^']+)'.*?MSG:(.*)").find(arg) ?: return
        val what = m.groupValues[1]; val extra = m.groupValues[2].trim()
        var status = "ok"
        when (what) {
            "PROTECTFD" -> {
                val fd = fds?.firstOrNull()
                status = if (fd != null && protectFd(fd)) "ok" else "cancel"
            }
            "IFCONFIG" -> tunnelIp = extra.split(" ").firstOrNull()
            "DNSSERVER" -> dns.add(extra)
            "PERSIST_TUN_ACTION" -> status = "OPEN_AFTER_CLOSE"
            "OPENTUN" -> { openTun(); return }
        }
        send("needok '$what' $status\n")
    }

    private fun protectFd(fd: FileDescriptor): Boolean {
        val pfd = ParcelFileDescriptor.dup(fd)
        return try { protectFn(pfd.fd) } finally { pfd.close() }
    }

    private fun openTun() {
        val a = FileDescriptor(); val b = FileDescriptor()
        Os.socketpair(OsConstants.AF_UNIX, OsConstants.SOCK_DGRAM, 0, a, b)
        ours = ParcelFileDescriptor.dup(a); Os.close(a)
        synchronized(lock) {
            val s = mgmt!!
            s.setFileDescriptorsForSend(arrayOf(b))
            s.outputStream.write("needok 'OPENTUN' ok\n".toByteArray()); s.outputStream.flush()
            s.setFileDescriptorsForSend(null)
        }
        Os.close(b)
        tunOut = FileOutputStream(ours!!.fileDescriptor)
        val input = FileInputStream(ours!!.fileDescriptor)
        thread(isDaemon = true) {
            val buf = ByteArray(32767)
            while (running) { val n = runCatching { input.read(buf) }.getOrDefault(-1); if (n <= 0) break; onPacket?.invoke(buf.copyOf(n)) }
        }
        ready.countDown()
    }

    override fun send(packet: ByteArray) { runCatching { tunOut?.write(packet) } }

    override fun stop() {
        running = false
        runCatching { mgmt?.close() }; runCatching { server?.close() }; runCatching { bound?.close() }
        runCatching { proc?.destroy() }
        runCatching { ours?.close() }
        confFile.delete(); sockFile.delete()
    }
}
