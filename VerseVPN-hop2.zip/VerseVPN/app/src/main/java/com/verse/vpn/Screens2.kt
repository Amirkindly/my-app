package com.verse.vpn

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun PowerIcon(color: Color, size: Dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension
        val w = s * 0.09f
        drawArc(color, -60f, 300f, false, topLeft = Offset(s * 0.15f, s * 0.2f), size = Size(s * 0.7f, s * 0.7f),
            style = Stroke(w, cap = StrokeCap.Round))
        drawLine(color, Offset(s / 2, s * 0.05f), Offset(s / 2, s * 0.5f), w, StrokeCap.Round)
    }
}

/** Session timer + live speed + session traffic. */
@Composable
fun LiveStats(connected: Boolean) {
    val since by VerseVpnService.since.collectAsState()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var down by remember { mutableLongStateOf(0L) }
    var up by remember { mutableLongStateOf(0L) }
    var total by remember { mutableLongStateOf(0L) }
    LaunchedEffect(connected) {
        if (!connected) { down = 0; up = 0; total = 0; return@LaunchedEffect }
        var lr = Meter.rx(); var lt = Meter.tx()
        val br = lr; val bt = lt
        while (true) {
            delay(1000)
            val r = Meter.rx(); val t = Meter.tx()
            down = r - lr; up = t - lt; lr = r; lt = t
            total = (r - br) + (t - bt)
            now = System.currentTimeMillis()
        }
    }
    val sec = if (connected && since > 0) (now - since) / 1000 else 0L
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Stat(stringResource(R.string.stat_time), if (connected) Fmt.clock(sec) else "--", Modifier.weight(1f))
            Stat(stringResource(R.string.stat_down), if (connected) Fmt.speed(down) else "--", Modifier.weight(1f))
            Stat(stringResource(R.string.stat_up), if (connected) Fmt.speed(up) else "--", Modifier.weight(1f))
            Stat(stringResource(R.string.stat_total), if (connected) Fmt.bytes(total) else "--", Modifier.weight(1f))
        }
    }
}

@Composable
private fun Stat(label: String, value: String, m: Modifier) {
    Column(m, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
fun QuickActions(go: (Int) -> Unit) {
    @Composable fun tile(icon: ImageVector, title: Int, sub: Int, tab: Int, m: Modifier) {
        Card(m.clickable { go(tab) }) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(6.dp))
                Text(stringResource(title), fontWeight = FontWeight.SemiBold)
                Text(stringResource(sub), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(R.string.quick_title), style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            tile(Icons.Filled.Lock, R.string.tab_configs, R.string.quick_configs_sub, 1, Modifier.weight(1f))
            tile(Icons.Filled.Menu, R.string.tab_apps, R.string.quick_apps_sub, 2, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            tile(Icons.Filled.Build, R.string.tab_tools, R.string.quick_tools_sub, 3, Modifier.weight(1f))
            tile(Icons.Filled.Settings, R.string.tab_settings, R.string.quick_settings_sub, 4, Modifier.weight(1f))
        }
    }
}

/** Tools (IP / latency / speed) + event log. */
@Composable
fun ToolsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    var mode by remember { mutableIntStateOf(0) }       // 0 tools, 1 logs
    var onlyErrors by remember { mutableStateOf(false) }
    var ipText by remember { mutableStateOf("") }
    var pingText by remember { mutableStateOf("") }
    var speedText by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val lines by AppLog.lines.collectAsState()
    val shown = remember(lines, onlyErrors) { lines.filter { !onlyErrors || it.level == 'E' }.asReversed() }

    fun fail(e: Throwable) = ctx.getString(R.string.tool_failed, e.message ?: e.javaClass.simpleName)

    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val tabs = listOf(R.string.tab_tools, R.string.logs_tab)
                tabs.forEachIndexed { i, t ->
                    if (mode == i) Button({ mode = i }) { Text(stringResource(t)) }
                    else OutlinedButton({ mode = i }) { Text(stringResource(t)) }
                }
            }
        }
        if (mode == 0) {
            item {
                ToolCard(R.string.tool_ip_title, ipText, !busy, R.string.tool_check) {
                    busy = true; ipText = ctx.getString(R.string.testing)
                    scope.launch { ipText = runCatching { NetTools.ip() }.getOrElse { fail(it) }; busy = false }
                }
            }
            item {
                ToolCard(R.string.tool_ping_title, pingText, !busy, R.string.test) {
                    busy = true; pingText = ctx.getString(R.string.testing)
                    scope.launch {
                        val targets = listOf("1.1.1.1", "8.8.8.8", "www.google.com")
                        val out = ArrayList<String>()
                        for (h in targets) {
                            val ms = NetTools.ping(h, 443)
                            out.add(if (ms >= 0) ctx.getString(R.string.ping_ms, h, ms) else ctx.getString(R.string.ping_timeout, h))
                        }
                        pingText = out.joinToString("\n")
                        busy = false
                    }
                }
            }
            item {
                ToolCard(R.string.tool_speed_title, speedText, !busy, R.string.test) {
                    busy = true; speedText = ctx.getString(R.string.testing)
                    scope.launch {
                        speedText = runCatching {
                            val (n, s) = NetTools.speed()
                            ctx.getString(R.string.speed_result, n * 8 / 1e6 / s, Fmt.bytes(n), s)
                        }.getOrElse { fail(it) }
                        busy = false
                    }
                }
            }
        } else {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (!onlyErrors) Button({ onlyErrors = false }) { Text(stringResource(R.string.logs_all)) }
                    else OutlinedButton({ onlyErrors = false }) { Text(stringResource(R.string.logs_all)) }
                    if (onlyErrors) Button({ onlyErrors = true }) { Text(stringResource(R.string.logs_errors)) }
                    else OutlinedButton({ onlyErrors = true }) { Text(stringResource(R.string.logs_errors)) }
                    Spacer(Modifier.weight(1f))
                    IconButton({ clip.setText(AnnotatedString(shown.asReversed().joinToString("\n") { AppLog.fmt(it) })) }) { Icon(Icons.Filled.Share, null) }
                    IconButton({ AppLog.clear() }) { Icon(Icons.Filled.Delete, null) }
                }
            }
            item { Text(stringResource(R.string.logs_note), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (shown.isEmpty()) item { Text(stringResource(R.string.logs_empty)) }
            items(shown) { l ->
                Text(AppLog.fmt(l), fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                    color = if (l.level == 'E') MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
            }
        }
    }
}

@Composable
private fun ToolCard(title: Int, result: String, enabled: Boolean, btn: Int, onRun: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(title), style = MaterialTheme.typography.titleMedium)
            if (result.isNotEmpty()) Text(result, style = MaterialTheme.typography.bodyMedium)
            OutlinedButton(onRun, enabled = enabled) { Text(stringResource(btn)) }
        }
    }
}

/** Custom DNS + MTU (applied on the next connect). */
@Composable
fun NetworkCard() {
    val ctx = LocalContext.current
    var d1 by remember { mutableStateOf(Prefs.dns1(ctx)) }
    var d2 by remember { mutableStateOf(Prefs.dns2(ctx)) }
    var mtu by remember { mutableStateOf(Prefs.mtu(ctx).toString()) }
    var msg by remember { mutableIntStateOf(0) }
    val ipKb = KeyboardOptions(keyboardType = KeyboardType.Number)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.net_title), style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(d1, { d1 = it.trim(); msg = 0 }, label = { Text(stringResource(R.string.dns_primary)) },
                singleLine = true, keyboardOptions = ipKb, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(d2, { d2 = it.trim(); msg = 0 }, label = { Text(stringResource(R.string.dns_secondary)) },
                singleLine = true, keyboardOptions = ipKb, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ d1 = "1.1.1.1"; d2 = "1.0.0.1"; msg = 0 }) { Text("Cloudflare") }
                OutlinedButton({ d1 = "8.8.8.8"; d2 = "8.8.4.4"; msg = 0 }) { Text("Google") }
                OutlinedButton({ d1 = "9.9.9.9"; d2 = "149.112.112.112"; msg = 0 }) { Text("Quad9") }
            }
            OutlinedTextField(mtu, { mtu = it.filter(Char::isDigit).take(4); msg = 0 }, label = { Text(stringResource(R.string.mtu)) },
                singleLine = true, keyboardOptions = ipKb, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({
                    val m = mtu.toIntOrNull() ?: 0
                    if (Prefs.validIp(d1) && Prefs.validIp(d2) && m in 576..1500) { Prefs.save(ctx, d1, d2, m); msg = R.string.net_saved }
                    else msg = R.string.net_bad
                }) { Text(stringResource(R.string.save)) }
                OutlinedButton({ Prefs.reset(ctx); d1 = Prefs.dns1(ctx); d2 = Prefs.dns2(ctx); mtu = Prefs.mtu(ctx).toString(); msg = R.string.net_saved }) {
                    Text(stringResource(R.string.reset))
                }
            }
            if (msg != 0) Text(stringResource(msg), fontSize = 12.sp,
                color = if (msg == R.string.net_bad) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
        }
    }
}
