package hev.htproxy;

/** JNI entry points of hev-socks5-tunnel (libhev-socks5-tunnel.so is built by the GitHub workflow). */
public class TProxyService {
    static { System.loadLibrary("hev-socks5-tunnel"); }
    public static native void TProxyStartService(String configPath, int fd);
    public static native void TProxyStopService();
    public static native long[] TProxyGetStats();
}
