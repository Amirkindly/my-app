# Verse VPN (double-hop) — status

DONE (UI + plumbing): import Hop 1 / Hop 2 configs (type auto-detected), username/password fields shown only when
the .ovpn contains `auth-user-pass`, per-app routing (all / all-except / only), VpnService with split tunnelling,
and TunnelChain = the packet router that makes two hops work inside Android's single-VPN limit.

Language: English or Persian, switchable in Settings (RTL supported). Credit: @Amir_verse on Telegram (Settings > About).

Hop 2 is OFF by default (switch on the Connect tab). When on, pick VPN (import a WireGuard config) or Proxy
(type a SOCKS5 address/port, optional username/password; "Test" does a real SOCKS5 handshake).
Proxy mode = ProxyEngine, which needs the hev-socks5-tunnel (tun2socks) Android library linked; the SOCKS5 proxy must
support UDP ASSOCIATE (DNS). Untested against the real library.

TODO: OpenVpnEngine (hop 1) needs OpenVPN3 native build. WireGuardEngine (hop 2) is written but untested.

Build: open in Android Studio -> Build > Build APK(s). Never bundle your .ovpn (it holds a private key); import it in the app.

GitHub: push this folder to a repo -> Actions tab -> "Build APK" -> download artifact "VerseVPN-debug-apk".
